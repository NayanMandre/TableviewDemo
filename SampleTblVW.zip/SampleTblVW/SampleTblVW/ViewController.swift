//
//  ViewController.swift
//  SampleTblVW
//
//  Created by Mac on 06/02/20.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    var allStudentsArr:[String] = []
   // var allStudentsArr:[[String:String]] = []
    var selectedRows:[IndexPath] = []
    var selectedRowsData:[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
       // tableView.allowsSelection = false
    //    allStudentsArr = [["name":"name1"],["name":"name2"],["name":"name3"],["name":"name4"],["name":"name5"],["name":"name6"],["name":"name7"],["name":"name8"],["name":"name9"],["name":"name10"],["name":"name11"],["name":"name12"],["name":"name13"],["name":"name14"],["name":"name15"],["name":"name16"],["name":"name17"],["name":"name19"],["name":"name20"]]
        
         allStudentsArr = ["name1","name2","name3","name4","name5","name6","name7","name8","name9","name10","name11","name12","name13","name14","name15","name16","name17","name19","name20"]
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allStudentsArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CV") as! TableViewCell
       // cell.nameLbl.text = allStudentsArr[indexPath.row]["name"]
           cell.nameLbl.text = allStudentsArr[indexPath.row]
        if selectedRows.contains(indexPath)
        {
            cell.CheckBox.setImage(UIImage(named:"selected.jpg"), for: .normal)
        }
        else
        {
            cell.CheckBox.setImage(UIImage(named:"unselected.png"), for: .normal)
        }
        cell.CheckBox.tag = indexPath.row
        cell.CheckBox.addTarget(self, action: #selector(checkBoxSelection(_:)), for: .touchUpInside)
        return cell
    }
    @objc func checkBoxSelection(_ sender:UIButton)
    {
        print("Index selected\(sender.tag)")
        print("cell selected unselected")
        let selectedIndexPath = IndexPath(row: sender.tag, section: 0)
        if self.selectedRows.contains(selectedIndexPath)
        {
            self.selectedRows.remove(at: self.selectedRows.index(of: selectedIndexPath)!)
            self.selectedRowsData.remove(at: self.selectedRowsData.index(of: allStudentsArr[selectedIndexPath.row])!)
        }
        else
        {
            self.selectedRows.append(selectedIndexPath)
            self.selectedRowsData.append(allStudentsArr[selectedIndexPath.row])
//            self.selectedRowsData.append(allStudentsArr[selectedIndexPath.row]["name"]!)
            
        }
        print("selected rows data---\(selectedRows)")
        print("selected rows data selectedRowsData---\(selectedRowsData)")

        self.tableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let abcViewController = storyboard?.instantiateViewController(withIdentifier: "New") as! NewViewController
       
        navigationController?.pushViewController(abcViewController, animated: true)
    }
    
    
    @IBAction func selectAllBtnAction(_ sender: UIBarButtonItem) {
        self.selectedRows = getAllIndexPaths()
        self.selectedRowsData = getAllIndexStrings()
        self.tableView.reloadData()
        
       // print("selected rows data---\(selectedRows)")
        print("selected rows data selectedRowsData---\(selectedRowsData)")

    }
    
    func getAllIndexPaths() -> [IndexPath] {
        var indexPaths: [IndexPath] = []
        for j in 0..<tableView.numberOfRows(inSection: 0) {
            indexPaths.append(IndexPath(row: j, section: 0))
            
        }
        return indexPaths
    }

    
    func getAllIndexStrings() -> [String] {
        var indexPaths: [String] = []
        for j in 0..<tableView.numberOfRows(inSection: 0) {
//            indexPaths.append(IndexPath(row: j, section: 0))
            indexPaths.append(allStudentsArr[j])
        }
        return indexPaths
    }
    
    

}

